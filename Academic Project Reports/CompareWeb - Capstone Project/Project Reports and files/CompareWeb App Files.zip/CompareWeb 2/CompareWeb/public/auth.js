// auth.js

// Import the Firebase functions from CDN
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-auth-domain",
  databaseURL: "your-database-url",
  projectId: "your-project-id",
  storageBucket: "your-storage-bucket",
  messagingSenderId: "your-messaging-sender-id",
  appId: "your-app-id"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

// Handle sign-in
const signInForm = document.getElementById('signinform');
signInForm.addEventListener('submit', (event) => {
  event.preventDefault(); // Prevent form submission

  const email = document.getElementById('emailInput').value;
  const password = document.getElementById('passwordInput').value;

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      // Successfully signed in
      const user = userCredential.user;

      // Fetch user data from Firebase Realtime Database
      const userRef = ref(db, 'users/' + user.uid);
      get(userRef).then((snapshot) => {
        if (snapshot.exists()) {
          const userData = snapshot.val();

          // Store username and favourites in localStorage
          localStorage.setItem("username", `${userData.firstName} ${userData.lastName}`);
          localStorage.setItem("favourites", JSON.stringify(userData.favourites || []));

          // Redirect to CompareWeb page
          window.location.href = "CompareWeb.html";
        } else {
          alert("No user data found!");
        }
      }).catch((error) => {
        console.error(error);
        alert("Error fetching user data.");
      });
    })
    .catch((error) => {
      console.error("Login failed: ", error.code, error.message);
      alert(`Login failed: ${error.message}`);
    });
});
