// Attach event listener to the search form
document.getElementById("search-form").addEventListener("submit", async function (event) {
    event.preventDefault(); // Prevent page reload on form submission

    const query = document.getElementById("query").value.trim(); // Get user input
    const resultsContainer = document.getElementById("search-results");

    // Input validation
    if (!query) {
        alert("Please enter a search term.");
        return;
    }

    // Show a loading indicator
    resultsContainer.innerHTML = "<p>Loading...</p>";

    try {
        // Capture user sign-in details
        const signedInUser = getSignedInUser(); // Custom function to get user info

        // Fetch search results from the backend
        const response = await fetch(`http://localhost:3000/search?q=${encodeURIComponent(query)}&user=${encodeURIComponent(signedInUser)}`);
        
        // Handle non-OK responses
        if (!response.ok) {
            throw new Error(`Error fetching search results: ${response.statusText}`);
        }

        // Parse the response data
        const results = await response.json(); 

        // Display results on the page
        displayResults(results); 
    } catch (error) {
        console.error("Error:", error);
        resultsContainer.innerHTML = `<p>An error occurred: ${error.message}</p>`;
    }
});

// Function to display search results on the page
function displayResults(results) {
    const resultsContainer = document.getElementById("search-results");
    resultsContainer.innerHTML = ""; // Clear previous results

    if (results.length === 0) {
        resultsContainer.innerHTML = "<p>No results found.</p>";
        return;
    }

    // Create a list of search results
    results.forEach((result) => {
        const item = document.createElement("div");
        item.className = "search-item";

        // Sanitize data before inserting into DOM
        const safeImage = encodeURI(result.image);
        const safeTitle = escapeHTML(result.title);

        item.innerHTML = `
            <img src="${safeImage}" alt="${safeTitle}" class="result-image">
            <div>
                <h3>${safeTitle}</h3>
                <p>Price: ${result.price}</p>
            </div>
        `;

        resultsContainer.appendChild(item);
    });
}

// Utility function to escape HTML
function escapeHTML(string) {
    return string.replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;")
                 .replace(/"/g, "&quot;")
                 .replace(/'/g, "&#039;");
}

// Function to get signed-in user info (Placeholder: you may replace it with actual sign-in logic)
function getSignedInUser() {
    // Replace this with actual sign-in check
    const user = localStorage.getItem("signedInUser");
    return user ? user : "Guest"; // Default to "Guest" if no user is signed in
}

// Add filter functionality
document.getElementById("filter-button").addEventListener("click", function() {
    const filterContainer = document.getElementById("filter-container");
    filterContainer.classList.toggle("visible"); // Toggle visibility of filter options
});

// Filter results based on user selections
document.getElementById("apply-filters").addEventListener("click", function() {
    const filterCategory = document.getElementById("filter-category").value;
    const filterPriceRange = document.getElementById("filter-price-range").value;

    // Apply filters to the current search query
    applyFilters(filterCategory, filterPriceRange);
});

// Function to apply filters to the search results
function applyFilters(category, priceRange) {
    // Assuming results are stored in a global variable or passed dynamically
    let filteredResults = results.filter(result => {
        let isCategoryMatch = category ? result.category === category : true;
        let isPriceMatch = priceRange ? result.price <= priceRange : true;

        return isCategoryMatch && isPriceMatch;
    });

    displayResults(filteredResults); // Display filtered results
}
